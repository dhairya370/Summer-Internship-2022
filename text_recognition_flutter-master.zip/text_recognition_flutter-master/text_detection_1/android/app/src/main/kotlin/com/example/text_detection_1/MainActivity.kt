package com.example.text_detection_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
